package com.olxgroup.kotlinmultiplatformworkshop

actual fun platformName(): String {
    return "Android"
}
